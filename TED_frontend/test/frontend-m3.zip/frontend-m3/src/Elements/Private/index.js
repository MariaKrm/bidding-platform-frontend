import React, { Component } from "react";

export default class Private extends Component {
	render() {
		return <div className='private'>
			<h2>This profile is  private</h2>
			<p>Follow this profile to see posts</p>
		</div>;
	}
}
